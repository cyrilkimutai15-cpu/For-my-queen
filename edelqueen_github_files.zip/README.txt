# A Universe Called Edelqueen

A single-page romantic surprise website made by Chizii.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to provide the public URL.

## Music note
The page attempts to start the embedded YouTube music automatically when it loads. Browsers (especially on phones) often block sound autoplay until the visitor interacts with the page. If that happens, the first tap anywhere on the page triggers playback. The YouTube player remains visible so the visitor can control playback.

All six gallery photos are embedded directly in `index.html`, so no separate image folder is needed.
